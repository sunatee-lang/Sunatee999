const menuBtn=document.getElementById('menuBtn');
const nav=document.getElementById('nav');
menuBtn.addEventListener('click',()=>nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
const copyBtn=document.getElementById('copyCode');
copyBtn.addEventListener('click',async()=>{
  const code=document.getElementById('htmlCode').innerText;
  try{await navigator.clipboard.writeText(code);copyBtn.textContent='คัดลอกแล้ว ✓';}
  catch(e){copyBtn.textContent='เลือกโค้ดแล้วกด Ctrl+C';}
  setTimeout(()=>copyBtn.textContent='คัดลอกโค้ด',2200);
});
const checks=[...document.querySelectorAll('.task input')];
function updateProgress(){
  const done=checks.filter(c=>c.checked).length;
  document.getElementById('taskCount').textContent=`${done}/${checks.length}`;
  document.getElementById('progressBar').style.width=`${done/checks.length*100}%`;
}
checks.forEach(c=>c.addEventListener('change',updateProgress));
