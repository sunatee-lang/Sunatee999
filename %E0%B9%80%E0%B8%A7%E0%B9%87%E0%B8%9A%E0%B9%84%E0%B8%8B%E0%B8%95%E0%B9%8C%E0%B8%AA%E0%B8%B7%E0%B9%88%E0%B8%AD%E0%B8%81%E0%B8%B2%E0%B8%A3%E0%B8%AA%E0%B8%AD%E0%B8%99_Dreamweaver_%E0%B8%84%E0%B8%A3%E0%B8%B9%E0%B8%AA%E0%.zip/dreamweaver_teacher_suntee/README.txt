เว็บไซต์สื่อการสอน Adobe Dreamweaver — ครูสุนที นกงาม

วิธีเปิดดูในเครื่อง
1. แตกไฟล์ ZIP
2. เปิดโฟลเดอร์ dreamweaver_teacher_suntee
3. ดับเบิลคลิก index.html เพื่อเปิดในเว็บเบราว์เซอร์

ไฟล์สำคัญ
- index.html : เนื้อหาเว็บไซต์
- style.css : รูปแบบ สี และการจัดวาง
- script.js : เมนู ปุ่มคัดลอกโค้ด และเช็กลิสต์งาน

วิธีเผยแพร่ด้วย GitHub Pages
1. สมัคร/เข้าสู่ระบบ https://github.com
2. กด New repository ตั้งชื่อ เช่น my-dreamweaver-site และเลือก Public
3. เข้า repository > Add file > Upload files
4. อัปโหลด index.html, style.css และ script.js (ให้อยู่ระดับเดียวกัน)
5. กด Commit changes
6. เข้า Settings > Pages
7. ที่ Build and deployment เลือก Deploy from a branch
8. เลือก Branch: main และ Folder: /(root) แล้วกด Save
9. รอสักครู่ แล้วเปิดลิงก์ที่แสดงในหน้า Pages
   รูปแบบลิงก์: https://ชื่อผู้ใช้.github.io/ชื่อ-repository/

หมายเหตุ
- ต้องมี index.html อยู่ที่โฟลเดอร์หลักของ repository
- หากแก้ไขเว็บไซต์ ให้อัปโหลดไฟล์ใหม่และ Commit changes
- GitHub Pages เหมาะกับเว็บไซต์แบบ Static (HTML/CSS/JavaScript)
- คู่มือทางการ: https://docs.github.com/en/pages/quickstart
